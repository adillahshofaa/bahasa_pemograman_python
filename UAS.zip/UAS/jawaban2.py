try:
    print(x)
except NameError:
    print("Variabel x tidak didefinisikan")
except:
    print("Ada yang tidak beres")
