from PySide6.QtWidgets import (QApplication, QLabel)

app = QApplication([])
nama_ibu = QLabel('Nama Ibu: Tuminah')
nama_ibu.show()
app.exec()
